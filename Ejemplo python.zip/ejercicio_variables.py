"""
#ejercicio 1

saldo_cuenta = 200.000
print(type(saldo_cuenta))

monto_retiro= 85.000
print(type(monto_retiro))
"""


"""
#ejercicio 2

nombre_usuario = "Ana Gonzales"
print(type(nombre_usuario))

fecha_hora = "2 de mayo a las 5:00pm"
print(type(fecha_hora))

mensaje = "Hola mundo"
print(type(mensaje))
"""

"""
#ejercicio 3

nom_usuario = "Julian Gomez"
print(type(nom_usuario))

numero_tarjeta = 103477159
print(type(numero_tarjeta))

saldo_disponible = 1.000000 
print(type(saldo_disponible))
"""


"""
#ejercicio 4

forma_lavado = "todo"
print(type(forma_lavado))

tiempo = "1 hora"
print(type(tiempo))

detergente = "ariel"
print(type(detergente))

agua = "500ml"
print(type(agua))
"""


#ejercicio 5

num_telefono = 312564895
print(type(num_telefono))

cobertura = "disponible"
print(type(cobertura))

credito = 30.000
print(type(credito))
