number_one = 8
number_two = 2

#This is a comment of one line 
#operacion de sumar dos numeros 

""""
This is a multi-line comment 

sumar = number_one + number_two

print(sumar) 

"""

multiplicacion = number_one * number_two
print (multiplicacion)
